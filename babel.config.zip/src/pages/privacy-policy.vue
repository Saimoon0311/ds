<template lang="">
  <section class="  ">
    <GeneralHeader />
    <div class="WordSection1 container pt-3">
      <p class="LNDocumentTitleShort" align="center" style="text-align: center">
        <span
          style="
            font-size: 20pt;
            mso-bidi-font-size: 10.5pt;
            font-family: Montserrat;
            mso-fareast-font-family: Calibri;
            text-transform: uppercase;
            mso-ansi-language: EN-AU;
            font-weight: bold;
          "
          >Privacy Policy<o:p></o:p
        ></span>
      </p>

      <p
        class="LNNumberedHeading1"
        style="
          margin-left: 0cm;
          text-indent: 0cm;
          mso-pagination: none;
          page-break-after: auto;
          mso-list: none;
          tab-stops: 36pt;
        "
      >
        <span lang="EN-US" style="font-family: Montserrat; font-weight: normal"
          >This Privacy Policy applies to all personal information collected by
          <span class="SpellE">Simplawfy</span> Pty Ltd via the website
          'makinglawsimple.com.au' (</span
        ><span lang="EN-US" style="font-family: Montserrat">Website</span
        ><span lang="EN-US" style="font-family: Montserrat; font-weight: normal"
          >).<o:p></o:p
        ></span>
      </p>

      <p
        class="LNNumberedHeading1"
        style="
          mso-pagination: none;
          page-break-after: auto;
          mso-list: l13 level1 lfo33;
        "
      >
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >1<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;
            </span></span
          ></span
        >
        <!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >What is personal information?<o:p></o:p
        ></span>
      </p>

      <p
        class="Level3"
        style="mso-pagination: none; mso-list: l13 level3 lfo33"
      >
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(a)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        >
        <!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >The Privacy Act 1988 (<span class="SpellE">Cth</span>) defines
          "personal information" as meaning information or an opinion about an
          identified individual or an individual who is reasonably
          identifiable:<o:p></o:p
        ></span>
      </p>

      <p
        class="LNText4"
        style="mso-pagination: none; mso-list: l13 level4 lfo33"
      >
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(i)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        >
        <!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >whether the information or opinion is true or not; and<o:p></o:p
        ></span>
      </p>

      <p
        class="LNText4"
        style="mso-pagination: none; mso-list: l13 level4 lfo33"
      >
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(ii)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        >
        <!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >whether the information or opinion is recorded in a material form or
          not.<o:p></o:p
        ></span>
      </p>

      <p
        class="Level3"
        style="mso-pagination: none; mso-list: l13 level3 lfo33"
      >
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(b)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        >
        <!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >If the information does not disclose your identity or enable your
          identity to be ascertained it will in most cases not be classified as
          "personal information" and will not be subject to this privacy
          policy.<o:p></o:p
        ></span>
      </p>

      <p
        class="LNNumberedHeading1"
        style="
          mso-pagination: none;
          page-break-after: auto;
          mso-list: l13 level1 lfo33;
        "
      >
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >2<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;
            </span></span
          ></span
        >
        <!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >What information do we collect?<o:p></o:p
        ></span>
      </p>

      <p class="LNIndentText1" style="mso-pagination: none">
        <span lang="EN-US" style="font-family: Montserrat"
          >The kind of personal information that we collect from you will depend
          on how you use the Website. The personal information which we collect
          and hold about you may include: personal details and confidential
          information including related to legal matters.<o:p></o:p
        ></span>
      </p>

      <p
        class="LNNumberedHeading1"
        style="
          mso-pagination: none;
          page-break-after: auto;
          mso-list: l13 level1 lfo33;
        "
      >
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >3<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;
            </span></span
          ></span
        >
        <!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >How do we collect your personal
          <span class="GramE">information</span>
          <o:p></o:p>
        </span>
      </p>

      <p
        class="Level3"
        style="mso-pagination: none; mso-list: l13 level3 lfo33"
      >
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(a)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        >
        <!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >We may collect personal information from you whenever you input such
          information into the Website.<o:p></o:p
        ></span>
      </p>

      <p
        class="Level3"
        style="mso-pagination: none; mso-list: l13 level3 lfo33"
      >
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(b)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        >
        <!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >We also collect cookies from your computer which enable us to tell
          when you use the Website and also to help
          <span class="SpellE">customise</span> your website experience. As a
          general rule, however, it is not possible to identify you personally
          from our use of cookies.<o:p></o:p
        ></span>
      </p>

      <p
        class="LNNumberedHeading1"
        style="
          mso-pagination: none;
          page-break-after: auto;
          mso-list: l13 level1 lfo33;
        "
      >
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >4<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;
            </span></span
          ></span
        >
        <!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >Purpose of collection<o:p></o:p
        ></span>
      </p>

      <p
        class="Level3"
        style="mso-pagination: none; mso-list: l13 level3 lfo33"
      >
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(a)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        >
        <!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >The purpose for which we collect personal information is to provide
          you with the best service experience possible on the Website.<o:p
          ></o:p
        ></span>
      </p>

      <p
        class="Level3"
        style="mso-pagination: none; mso-list: l13 level3 lfo33"
      >
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(b)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        >
        <!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >We customarily disclose personal information only to our service
          providers who assist us in operating the Website. Your personal
          information may also be exposed from time to time to maintenance and
          support personnel acting in the normal course of their duties.<o:p
          ></o:p
        ></span>
      </p>

      <p
        class="Level3"
        style="mso-pagination: none; mso-list: l13 level3 lfo33"
      >
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(c)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        >
        <!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >By using our Website, you consent to the receipt of direct marketing
          material. We will only use your personal information for this purpose
          if we have collected such information direct from you, and if it is
          material of a type which you would reasonably expect to receive from
          us. We do not use sensitive personal information in direct marketing
          activity. Our direct marketing material will include a simple means by
          which you can request not to receive further communications of this
          nature.<o:p></o:p
        ></span>
      </p>

      <p
        class="LNNumberedHeading1"
        style="
          mso-pagination: none;
          page-break-after: auto;
          mso-list: l13 level1 lfo33;
        "
      >
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >5<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;
            </span></span
          ></span
        >
        <!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >Access and correction<o:p></o:p
        ></span>
      </p>

      <p class="LNIndentText1" style="mso-pagination: none">
        <span lang="EN-US" style="font-family: Montserrat"
          >Australian Privacy Principle 12 permits you to obtain access to the
          personal information we hold about you in certain circumstances and
          Australian Privacy Principle 13 allows you to correct inaccurate
          personal information subject to certain exceptions. If you would like
          to obtain such access, please contact us as set out below.<o:p></o:p
        ></span>
      </p>

      <p
        class="LNNumberedHeading1"
        style="
          mso-pagination: none;
          page-break-after: auto;
          mso-list: l13 level1 lfo33;
        "
      >
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >6<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;
            </span></span
          ></span
        >
        <!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >Complaint procedure<o:p></o:p
        ></span>
      </p>

      <p class="LNIndentText1" style="mso-pagination: none">
        <span lang="EN-US" style="font-family: Montserrat"
          >If you have a complaint concerning the manner in which we maintain
          the privacy of your personal information, please contact us as set out
          below. All complaints will be considered by our Privacy Officer and we
          may seek further information from you to clarify our concerns. If we
          agree that your complaint is well founded, we will, in consultation
          with you, take appropriate steps to rectify the problem. If you remain
          dissatisfied with the outcome, you may refer the matter to the Office
          of the Australian Information Commissioner.<o:p></o:p
        ></span>
      </p>

      <p
        class="LNNumberedHeading1"
        style="
          mso-pagination: none;
          page-break-after: auto;
          mso-list: l13 level1 lfo33;
        "
      >
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >7<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;
            </span></span
          ></span
        >
        <!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >Overseas transfer<o:p></o:p
        ></span>
      </p>

      <p class="LNIndentText1" style="mso-pagination: none">
        <span lang="EN-US" style="font-family: Montserrat"
          >Your personal information will not be disclosed to recipients outside
          Australia unless you expressly request us to do so. If you request us
          to transfer your personal information to an overseas recipient, the
          overseas recipient will not be required to comply with the Australian
          Privacy Principles and we will not be liable for any mishandling of
          your information in such circumstances.<o:p></o:p
        ></span>
      </p>

      <p
        class="LNNumberedHeading1"
        style="
          mso-pagination: none;
          page-break-after: auto;
          mso-list: l13 level1 lfo33;
        "
      >
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >8<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;
            </span></span
          ></span
        >
        <!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >How to contact us about privacy<o:p></o:p
        ></span>
      </p>

      <p class="LNIndentText1" style="mso-pagination: none">
        <span lang="EN-US" style="font-family: Montserrat"
          >If you have any queries, or if you seek access to your personal
          information, or if you have a complaint about our privacy practices,
          you can contact us through: </span
        ><span lang="EN-US"
          ><a href="mailto:info@makinglawsimple.com.au"
            ><span style="font-family: Montserrat"
              >info@makinglawsimple.com.au</span
            ></a
          ></span
        ><span lang="EN-US" style="font-family: Montserrat">. <o:p></o:p></span>
      </p>
    </div>
    

    <!-- <div class="card flex justify-content-center">
        <MultiSelectPrime v-model="selectedCities" :options="cities" optionLabel="name" placeholder="Select Cities"
            :maxSelectedLabels="3" class="w-full md:w-20rem" />
    </div> -->


    <div class="footer">
      <MainFooter />
    </div>

  </section>
</template>
<script>

import GeneralHeader from "../pages/GeneralHeader.vue";
import MainFooter from "../components/global/MainFooter.vue";

// import { ref } from "vue";


export default {
  components: {
    GeneralHeader,
    MainFooter
  },
  // data() {
  //   return {
  //     selectedCities: ref(),
  //     cities: ref([
  //       { name: 'New York', code: 'NY' },
  //       { name: 'Rome', code: 'RM' },
  //       { name: 'London', code: 'LDN' },
  //       { name: 'Istanbul', code: 'IST' },
  //       { name: 'Paris', code: 'PRS' }
  //     ])
  //   }
  // },

  name: "privacy-policy",
};
</script>
<style scoped>
.LNNumberedHeading1 span {
  font-size: 14pt !important;
  font-weight: bold;
}
</style>
