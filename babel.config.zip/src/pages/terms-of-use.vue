<template lang="">
  <section class=" ">
    <GeneralHeader />
    
    <div class="WordSection1 container pt-3">
      <p class="LNDocumentTitleShort" align="center" style="text-align: center">
        <span
          style="
            font-size: 20pt;
            mso-bidi-font-size: 10.5pt;
            font-family: Montserrat;
            mso-fareast-font-family: Calibri;
            text-transform: uppercase;
            mso-ansi-language: EN-AU;
            font-weight: bold;
          "
          >Website terms of use<o:p></o:p
        ></span>
      </p>

      <p class="LNMarginText">
        <span class="SpellE"
          ><span lang="EN-US" style="font-family: Montserrat"
            >Simplawfy</span
          ></span
        ><span lang="EN-US" style="font-family: Montserrat">
          Pty Ltd (<span class="SpellE"
            ><span class="LNDefinedTermChar"
              ><span style="font-family: Montserrat">Simplawfy</span></span
            ></span
          >) owns and operates this website 'makinglawsimple.com.au' (<b
            style="mso-bidi-font-weight: normal"
            >Website</b
          >). Access to and use of this Website<b
            style="mso-bidi-font-weight: normal"
          >
          </b
          >and the products and services available through this Website
          (collectively,
          <span class="LNDefinedTermChar"
            ><span style="font-family: Montserrat">Services</span></span
          >) is subject to the following terms, conditions and notices (<span
            class="LNDefinedTermChar"
            ><span style="font-family: Montserrat">Terms of Use</span></span
          >). By using the Services, you are agreeing to all of the Terms of
          Use, as may be updated by us from time to time. You should check this
          page regularly to take notice of any changes that may have been made
          to the Terms of Use.<o:p></o:p
        ></span>
      </p>

      <p class="LNNumberedHeading1" style="mso-list: l8 level1 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >1<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >Website access<o:p></o:p
        ></span>
      </p>

      <p class="LNIndentText1">
        <span lang="EN-US" style="font-family: Montserrat"
          >Access to this Website is permitted on a temporary basis, and
          <span class="SpellE">Simplawfy</span> reserves the right to withdraw
          or amend the Services without notice. Your use of the Website is at
          your own risk. The Website is provided on an "as is" and "as
          available" basis. <span class="SpellE">Simplawfy</span> does not
          warrant that the Website will be uninterrupted or error-free.
          <span class="SpellE">Simplawfy</span> will not be liable if for any
          reason this Website is unavailable at any time or for any period. From
          time to time, <span class="SpellE">Simplawfy</span> may restrict
          access to some parts or all of this Website.<o:p></o:p
        ></span>
      </p>

      <p class="LNNumberedHeading1" style="mso-list: l8 level1 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >2<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >Terms &amp; Conditions for clients and lawyers<o:p></o:p
        ></span>
      </p>

      <p class="LNIndentText1">
        <span lang="EN-US" style="font-family: Montserrat"
          >Your use of the Website may be as a Client or Lawyer (as those terms
          are defined in the Terms &amp; Conditions for Clients and Terms &amp;
          Conditions for Lawyers):<o:p></o:p
        ></span>
      </p>

      <p class="LNText3" style="mso-list: l8 level3 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(a)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >If you are a Client, you also agree to be bound by the Terms &amp;
          Conditions for Clients, which is available
          <a target="_blank" href="customer/terms-and-conditions.html">here</a>
          .<o:p></o:p
        ></span>
      </p>

      <p class="LNText3" style="mso-list: l8 level3 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(b)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >If you are a Lawyer, you also agree to be bound by the Terms &amp;
          Conditions for Lawyers, which is available
          <a target="_blank" href="lawyer/terms-and-conditions.html">here</a>
          .<o:p></o:p
        ></span>
      </p>

      <p class="LNNumberedHeading1" style="mso-list: l8 level1 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >3<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >Linked sites<o:p></o:p
        ></span>
      </p>

      <p class="LNIndentText1">
        <span lang="EN-US" style="font-family: Montserrat"
          >This Website may contain links to other websites (<span
            class="LNDefinedTermChar"
            ><span style="font-family: Montserrat">Linked Sites</span></span
          >), which are not operated by <span class="SpellE">Simplawfy</span>.
          <span class="SpellE">Simplawfy</span> has no control over the Linked
          Sites and accepts no responsibility for them or for any loss or damage
          that may arise from your use of them. Your use of the Linked Sites
          will be subject to the terms of use and service contained within each
          such site.<o:p></o:p
        ></span>
      </p>

      <p class="LNNumberedHeading1" style="mso-list: l8 level1 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >4<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >Privacy policy<o:p></o:p
        ></span>
      </p>

      <p class="LNIndentText1">
        <span class="SpellE"
          ><span lang="EN-US" style="font-family: Montserrat"
            >Simplawfy's</span
          ></span
        ><span lang="EN-US" style="font-family: Montserrat">
          privacy policy, which sets out how your information is used, can be
          found
          <router-link to="/privacy-policy">here</router-link>
          . By using this Website, you consent to the processing described the
          privacy policy and warrant that all data provided by you is
          accurate.<o:p></o:p
        ></span>
      </p>

      <p class="LNNumberedHeading1" style="mso-list: l8 level1 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >5<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >Prohibitions<o:p></o:p
        ></span>
      </p>

      <p class="LNText3" style="mso-list: l8 level3 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(a)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >You must not misuse this Website. You must not:<o:p></o:p
        ></span>
      </p>

      <p class="LNText4" style="mso-list: l8 level4 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(i)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >commit or encourage a criminal offense;<o:p></o:p
        ></span>
      </p>

      <p class="LNText4" style="mso-list: l8 level4 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(ii)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >transmit or distribute a virus, trojan, worm, logic bomb or any other
          malware or material which is malicious, technologically harmful, in
          breach of confidence or in any way offensive or obscene;<o:p></o:p
        ></span>
      </p>

      <p class="LNText4" style="mso-list: l8 level4 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(iii)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >hack into any aspect of the Service; <o:p></o:p
        ></span>
      </p>

      <p class="LNText4" style="mso-list: l8 level4 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(iv)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >corrupt data; <o:p></o:p
        ></span>
      </p>

      <p class="LNText4" style="mso-list: l8 level4 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(v)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >cause annoyance to other users;<o:p></o:p
        ></span>
      </p>

      <p class="LNText4" style="mso-list: l8 level4 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(vi)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >infringe upon the rights of any other person's proprietary
          rights;<o:p></o:p
        ></span>
      </p>

      <p class="LNText4" style="mso-list: l8 level4 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(vii)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >send any unsolicited advertising or promotional material, commonly
          referred to as "spam"; or<o:p></o:p
        ></span>
      </p>

      <p class="LNText4" style="mso-list: l8 level4 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(viii)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >attempt to affect the performance or functionality of any computer
          facilities of or accessed through this Website.<o:p></o:p
        ></span>
      </p>

      <p class="LNText3" style="mso-list: l8 level3 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(b)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span class="SpellE"
          ><span lang="EN-US" style="font-family: Montserrat"
            >Simplawfy</span
          ></span
        ><span lang="EN-US" style="font-family: Montserrat">
          will not be liable for any loss or damage caused by a distributed
          denial-of-service attack, viruses or other technologically harmful
          material that may infect your computer equipment, computer programs,
          data or other proprietary material due to your use of this Website or
          to your downloading of any material posted on it, or on any Linked
          Sites.<o:p></o:p
        ></span>
      </p>

      <p class="LNNumberedHeading1" style="mso-list: l8 level1 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >6<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >Intellectual property, software and content<o:p></o:p
        ></span>
      </p>

      <p class="LNIndentText1">
        <span lang="EN-US" style="font-family: Montserrat"
          >The intellectual property rights in all software and content
          (including photographic images) made available to you on or through
          this Website remain the property of
          <span class="SpellE">Simplawfy</span> or its licensors and are
          protected by copyright laws and treaties around the world. All such
          rights are reserved by <span class="SpellE">Simplawfy</span> and its
          licensors. You may store, print and display the content supplied
          solely for your own personal use. You are not permitted to publish,
          manipulate, distribute or otherwise reproduce, in any format, any of
          the content or copies of the content supplied to you or which appears
          on this Website nor may you use any such content in connection with
          any business or commercial enterprise.<o:p></o:p
        ></span>
      </p>

      <p class="LNNumberedHeading1" style="mso-list: l8 level1 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >7<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >Disclaimer of liability<o:p></o:p
        ></span>
      </p>

      <p class="LNText3" style="mso-list: l8 level3 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(a)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >Subject to any non-excludable consumer guarantees and other consumer
          protection provisions set out in the Australian Consumer Law, the
          material displayed on this Website is provided without any guarantees,
          conditions or warranties as to its accuracy. <o:p></o:p
        ></span>
      </p>

      <p class="LNText3" style="mso-list: l8 level3 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(b)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >To the fullest extent permitted by law,
          <span class="SpellE">Simplawfy</span> hereby expressly excludes all
          warranties and other terms which might otherwise be implied by
          statute, common law or the law of equity and must not be liable for
          any damages whatsoever, including but without limitation to any
          direct, indirect, special, consequential, punitive or incidental
          damages, or damages for loss of use, profits, data or other
          intangibles, damage to goodwill or reputation, or the cost of
          procurement of substitute goods and services, arising out of or
          related to the use, inability to use, performance or failures of this
          Website or the Linked Sites and any materials posted on those sites,
          irrespective of whether such damages were foreseeable or arise in
          contract, tort, equity, restitution, by statute, at common law or
          otherwise. <o:p></o:p
        ></span>
      </p>

      <p class="LNText3" style="mso-list: l8 level3 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >(c)<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >This does not affect any
          <span class="SpellE">Simplawfy's</span> liability which cannot be
          excluded or limited under applicable law.<o:p></o:p
        ></span>
      </p>

      <p class="LNNumberedHeading1" style="mso-list: l8 level1 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >8<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >Linking to this website<o:p></o:p
        ></span>
      </p>

      <p class="LNIndentText1">
        <span lang="EN-US" style="font-family: Montserrat"
          >You may link to our home page, provided you do so in a way that is
          fair and legal and does not damage our reputation or take advantage of
          it, but you must not establish a link in such a way as to suggest any
          form of association, approval or endorsement on our part where none
          exists. You must not establish a link from any website that is not
          owned by you. This Website must not be framed on any other site, nor
          may you create a link to any part of this Website other than the home
          page. <span class="SpellE">Simplawfy</span> reserves the right to
          withdraw linking permission without notice.<o:p></o:p
        ></span>
      </p>

      <p class="LNNumberedHeading1" style="mso-list: l8 level1 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >9<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >Disclaimer as to ownership of trade marks, images of personalities
          and <span class="GramE">third party</span> copyright<o:p></o:p
        ></span>
      </p>

      <p class="LNIndentText1">
        <span lang="EN-US" style="font-family: Montserrat"
          >Except where expressly stated to the contrary all persons (including
          their names and images), third party
          <span class="SpellE">trade marks</span> and content, services and/or
          locations featured on this Website are in no way associated, linked or
          affiliated with <span class="SpellE">Simplawfy</span> and you should
          not rely on the existence of such a connection or affiliation. Any
          trade marks/names featured on this Website are owned by the respective
          trade mark owners. Where a trade mark or brand name is referred to it
          is used solely to describe or identify the products and services and
          is in no way an assertion that such products or services are endorsed
          by or connected to <span class="SpellE">Simplawfy</span>.<o:p></o:p
        ></span>
      </p>

      <p class="LNNumberedHeading1" style="mso-list: l8 level1 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >10<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >Indemnity<o:p></o:p
        ></span>
      </p>

      <p class="LNIndentText1">
        <span lang="EN-US" style="font-family: Montserrat"
          >You agree to indemnify, defend and hold harmless
          <span class="SpellE">Simplawfy</span>, its directors, officers,
          employees, consultants, agents, and affiliates, from any and all
          <span class="GramE">third party</span> claims, liability, damages or
          costs (including, but not limited to, legal fees) arising from your
          use of this Website or your breach of the Terms of Use.<o:p></o:p
        ></span>
      </p>

      <p class="LNNumberedHeading1" style="mso-list: l8 level1 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >11<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >Variation<o:p></o:p
        ></span>
      </p>

      <p class="LNIndentText1">
        <span class="SpellE"
          ><span lang="EN-US" style="font-family: Montserrat"
            >Simplawfy</span
          ></span
        ><span lang="EN-US" style="font-family: Montserrat">
          reserves the right to vary these Terms of Use, or remove or vary the
          Services or any page of this Website, at any time and without notice.
          Variations will be effective immediately upon publication on this
          Website. Your continued use of the Website following such publication
          will represent an agreement by you to be bound by the Terms of Use as
          varied.<o:p></o:p
        ></span>
      </p>

      <p class="LNNumberedHeading1" style="mso-list: l8 level1 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >12<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >Invalidity<o:p></o:p
        ></span>
      </p>

      <p class="LNIndentText1">
        <span lang="EN-US" style="font-family: Montserrat"
          >If any part of the Terms of Use is unenforceable (including any
          provision in which <span class="SpellE">Simplawfy</span> excludes its
          liability to you) the enforceability of any other part of the Terms of
          Use will not be affected and all other clauses remain in full force
          and effect. So far as possible where any clause/sub-clause or part of
          a clause/sub-clause can be severed to render the remaining part valid,
          the clause must be interpreted accordingly. Alternatively, you agree
          that the clause must be rectified and interpreted in such a way that
          closely resembles the original meaning of the clause/sub-clause as is
          permitted by law.<o:p></o:p
        ></span>
      </p>

      <p class="LNNumberedHeading1" style="mso-list: l8 level1 lfo8">
        <!--[if !supportLists]--><span
          lang="EN-US"
          style="
            font-family: Montserrat;
            mso-fareast-font-family: Montserrat;
            mso-bidi-font-family: Montserrat;
          "
          ><span style="mso-list: Ignore"
            >13<span style="font: 7pt 'Times New Roman'"
              >&nbsp;&nbsp;
            </span></span
          ></span
        ><!--[endif]--><span lang="EN-US" style="font-family: Montserrat"
          >Complaints<o:p></o:p
        ></span>
      </p>

      <p class="LNIndentText1">
        <span class="SpellE"
          ><span lang="EN-US" style="font-family: Montserrat"
            >Simplawfy</span
          ></span
        ><span lang="EN-US" style="font-family: Montserrat">
          operates a <span class="GramE">complaints</span> handling procedure to
          try to resolve disputes when they first arise. Please let us know if
          you have any complaints or comments by emailing </span
        ><span lang="EN-US"
          ><a href="mailto:info@makinglawsimple.com.au"
            ><span style="font-family: Montserrat"
              >info@makinglawsimple.com.au</span
            ></a
          ></span
        ><span lang="EN-US" style="font-family: Montserrat">.<o:p></o:p></span>
      </p>
    </div>
    <div class="footer">
      <MainFooter />
    </div>
  </section>

</template>
<script>
import GeneralHeader from "../pages/GeneralHeader.vue";
import MainFooter from "../components/global/MainFooter.vue";

export default {
  components: {
    MainFooter,
    GeneralHeader
  },

  name: "terms-of-use",
};
</script>
<style scoped>
.LNNumberedHeading1 span {
  font-size: 14pt !important;
  font-weight: bold;
}
</style>
